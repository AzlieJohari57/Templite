import React, { useState } from 'react';
import { Upload, Plus, Minus, Send, User, Briefcase, GraduationCap, Award, Target, Users, Code, Heart, Star, Calendar } from 'lucide-react';
import { uploadImage, submitResume } from '../services/api';

interface Experience {
  company: string;
  title: string;
  location: string;
  duration: string;
  details: string;
}

interface Language {
  language: string;
  proficiency: string;
}

interface Skill {
  skill: string;
  percentage: number;
}

interface ExtracurricularActivity {
  title: string;
  date: string;
  details: string;
}

interface FormData {
  name: string;
  address: string;
  email: string;
  telephone: string;
  linkedin: string;
  title: string;
  about: string;
  image: File | null;
  languages: Language[];
  experiences: Experience[];
  education: {
    degree: string;
    institution: string;
    cgpa: string;
  };
  strength: string;
  reference: {
    name: string;
    position: string;
    company: string;
    contact: string;
  };
  technicalSkills: Skill[];
  softSkills: Skill[];
  certifications: string[];
  achievements: string[];
  extracurricularActivities: ExtracurricularActivity[];
}

const ResumeForm: React.FC = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    name: '',
    address: '',
    email: '',
    telephone: '',
    linkedin: '',
    title: '',
    about: '',
    image: null,
    languages: [{ language: '', proficiency: 'beginner' }],
    experiences: [{ company: '', title: '', location: '', duration: '', details: '' }],
    education: { degree: '', institution: '', cgpa: '' },
    strength: '',
    reference: { name: '', position: '', company: '', contact: '' },
    technicalSkills: [{ skill: '', percentage: 50 }],
    softSkills: [{ skill: '', percentage: 50 }],
    certifications: [''],
    achievements: [''],
    extracurricularActivities: [{ title: '', date: '', details: '' }]
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleNestedInputChange = (section: string, field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section as keyof FormData] as any,
        [field]: value
      }
    }));
  };

  const handleArrayInputChange = (section: string, index: number, field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [section]: (prev[section as keyof FormData] as any[]).map((item, i) =>
        i === index ? { ...item, [field]: value } : item
      )
    }));
  };

  const handleSimpleArrayChange = (section: string, index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      [section]: (prev[section as keyof FormData] as string[]).map((item, i) =>
        i === index ? value : item
      )
    }));
  };

  const addArrayItem = (section: string, defaultItem: any) => {
    setFormData(prev => ({
      ...prev,
      [section]: [...(prev[section as keyof FormData] as any[]), defaultItem]
    }));
  };

  const removeArrayItem = (section: string, index: number) => {
    setFormData(prev => ({
      ...prev,
      [section]: (prev[section as keyof FormData] as any[]).filter((_, i) => i !== index)
    }));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({ ...prev, image: e.target.files![0] }));
    }
  };

  const formatSubmissionData = (gdriveUrl: string) => {
    const formatLanguages = () => {
      return formData.languages
        .filter(lang => lang.language.trim())
        .map(lang => `${lang.language} ${lang.proficiency}`)
        .join(', ');
    };

    const formatExperiences = () => {
      const validExperiences = formData.experiences.filter(exp => 
        exp.company.trim() || exp.title.trim() || exp.details.trim()
      );
      
      if (validExperiences.length === 0) {
        return "No work experience";
      }
      
      return validExperiences.map(exp => 
        `${exp.title} at ${exp.company}, ${exp.location} (${exp.duration}): ${exp.details}`
      ).join('; ');
    };

    const formatSkills = (skills: Skill[]) => {
      return skills
        .filter(skill => skill.skill.trim())
        .map(skill => `${skill.skill} ${skill.percentage}%`)
        .join(', ');
    };

    const formatList = (items: string[]) => {
      return items.filter(item => item.trim()).join(', ');
    };

    const formatExtracurricular = () => {
      return formData.extracurricularActivities
        .filter(activity => activity.title.trim())
        .map(activity => `${activity.title} (${activity.date}): ${activity.details}`)
        .join(', ');
    };

    return {
      id: Math.floor(Math.random() * 10000),
      template: "A",
      gdrive_url: gdriveUrl,
      language_selected: "English",
      user_image: "",
      name: formData.name,
      adress: formData.address, // Note: keeping the original typo from the spec
      email: formData.email,
      telephone: formData.telephone,
      linkedin: formData.linkedin,
      title: formData.title,
      about: formData.about,
      language: formatLanguages(),
      experience: formatExperiences(),
      education: `${formData.education.degree}, ${formData.education.institution}, CGPA: ${formData.education.cgpa}`,
      strength: formData.strength,
      reference: formData.reference.name ? 
        `${formData.reference.name}, ${formData.reference.position}, ${formData.reference.company}, ${formData.reference.contact}` : '',
      technical_skills: formatSkills(formData.technicalSkills),
      soft_skills: formatSkills(formData.softSkills),
      certification: formatList(formData.certifications),
      Achivements: formatList(formData.achievements), // Note: keeping the original typo from the spec
      extracurricular_activities: formatExtracurricular()
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // First upload image
      let gdriveUrl = '';
      if (formData.image) {
        const uploadResponse = await uploadImage(formData.image);
        gdriveUrl = uploadResponse.gdrive_url;
      }

      // Then submit the full data
      const submissionData = formatSubmissionData(gdriveUrl);
      await submitResume(submissionData);
      
      alert('Resume submitted successfully!');
    } catch (error) {
      console.error('Submission error:', error);
      alert('Failed to submit resume. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8 border border-yellow-200">
      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Basic Information */}
        <section className="border-b border-gray-200 pb-8">
          <div className="flex items-center mb-6">
            <User className="w-6 h-6 text-yellow-600 mr-3" />
            <h2 className="text-2xl font-semibold text-gray-900">Basic Information</h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Job Title *</label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email *</label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
              <input
                type="tel"
                required
                value={formData.telephone}
                onChange={(e) => handleInputChange('telephone', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
              />
            </div>
            
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Address *</label>
              <input
                type="text"
                required
                value={formData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">LinkedIn Profile</label>
              <input
                type="text"
                value={formData.linkedin}
                onChange={(e) => handleInputChange('linkedin', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Profile Image</label>
              <div className="flex items-center space-x-4">
                <label className="cursor-pointer bg-yellow-50 hover:bg-yellow-100 text-yellow-700 px-4 py-2 rounded-lg transition-colors flex items-center border border-yellow-200">
                  <Upload className="w-4 h-4 mr-2" />
                  Choose File
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="hidden"
                  />
                </label>
                {formData.image && (
                  <span className="text-sm text-gray-600">{formData.image.name}</span>
                )}
              </div>
            </div>
            
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">About Me</label>
              <textarea
                value={formData.about}
                onChange={(e) => handleInputChange('about', e.target.value)}
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                placeholder="Brief description about yourself..."
              />
            </div>
          </div>
        </section>

        {/* Language Proficiency */}
        <section className="border-b border-gray-200 pb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Target className="w-6 h-6 text-yellow-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Language Proficiency</h2>
            </div>
            <button
              type="button"
              onClick={() => addArrayItem('languages', { language: '', proficiency: 'beginner' })}
              className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center shadow-md"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Language
            </button>
          </div>
          
          {formData.languages.map((lang, index) => (
            <div key={index} className="flex items-center space-x-4 mb-4 bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <input
                type="text"
                placeholder="Language"
                value={lang.language}
                onChange={(e) => handleArrayInputChange('languages', index, 'language', e.target.value)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
              />
              <select
                value={lang.proficiency}
                onChange={(e) => handleArrayInputChange('languages', index, 'proficiency', e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
              >
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="professional">Professional</option>
                <option value="native">Native</option>
              </select>
              {formData.languages.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeArrayItem('languages', index)}
                  className="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg transition-colors text-sm font-medium"
                >
                  Delete
                </button>
              )}
            </div>
          ))}
        </section>

        {/* Work Experience */}
        <section className="border-b border-gray-200 pb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Briefcase className="w-6 h-6 text-yellow-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Work Experience</h2>
            </div>
            {formData.experiences.length < 3 && (
              <button
                type="button"
                onClick={() => addArrayItem('experiences', { company: '', title: '', location: '', duration: '', details: '' })}
                className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center shadow-md"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Experience
              </button>
            )}
          </div>
          
          {formData.experiences.length === 0 || (formData.experiences.length === 1 && !formData.experiences[0].company.trim()) ? (
            <div className="text-center py-8 text-gray-500 bg-yellow-50 rounded-lg border border-yellow-200">
              <p>No work experience yet? That's okay for fresh graduates!</p>
            </div>
          ) : null}
          
          {formData.experiences.map((exp, index) => (
            <div key={index} className="bg-yellow-50 p-6 rounded-lg mb-4 border border-yellow-200">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Experience {index + 1}</h3>
                {formData.experiences.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeArrayItem('experiences', index)}
                    className="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg transition-colors text-sm font-medium"
                  >
                    Delete
                  </button>
                )}
              </div>
              
              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <input
                  type="text"
                  placeholder="Company Name"
                  value={exp.company}
                  onChange={(e) => handleArrayInputChange('experiences', index, 'company', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                />
                <input
                  type="text"
                  placeholder="Job Title"
                  value={exp.title}
                  onChange={(e) => handleArrayInputChange('experiences', index, 'title', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                />
                <input
                  type="text"
                  placeholder="Location"
                  value={exp.location}
                  onChange={(e) => handleArrayInputChange('experiences', index, 'location', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                />
                <input
                  type="text"
                  placeholder="Duration (e.g., Jan 2020 - Dec 2022)"
                  value={exp.duration}
                  onChange={(e) => handleArrayInputChange('experiences', index, 'duration', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                />
              </div>
              
              <textarea
                placeholder="Job details and responsibilities..."
                value={exp.details}
                onChange={(e) => handleArrayInputChange('experiences', index, 'details', e.target.value)}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
              />
            </div>
          ))}
        </section>

        {/* Education */}
        <section className="border-b border-gray-200 pb-8">
          <div className="flex items-center mb-6">
            <GraduationCap className="w-6 h-6 text-yellow-600 mr-3" />
            <h2 className="text-2xl font-semibold text-gray-900">Education</h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <input
              type="text"
              placeholder="Degree"
              value={formData.education.degree}
              onChange={(e) => handleNestedInputChange('education', 'degree', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
            />
            <input
              type="text"
              placeholder="Institution"
              value={formData.education.institution}
              onChange={(e) => handleNestedInputChange('education', 'institution', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
            />
            <input
              type="text"
              placeholder="CGPA"
              value={formData.education.cgpa}
              onChange={(e) => handleNestedInputChange('education', 'cgpa', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
            />
          </div>
        </section>

        {/* Strength */}
        <section className="border-b border-gray-200 pb-8">
          <div className="flex items-center mb-6">
            <Star className="w-6 h-6 text-yellow-600 mr-3" />
            <h2 className="text-2xl font-semibold text-gray-900">Strengths</h2>
          </div>
          
          <textarea
            value={formData.strength}
            onChange={(e) => handleInputChange('strength', e.target.value)}
            rows={4}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
            placeholder="Describe your key strengths and what makes you unique..."
          />
        </section>

        {/* Technical Skills */}
        <section className="border-b border-gray-200 pb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Code className="w-6 h-6 text-yellow-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Technical Skills</h2>
            </div>
            {formData.technicalSkills.length < 3 && (
              <button
                type="button"
                onClick={() => addArrayItem('technicalSkills', { skill: '', percentage: 50 })}
                className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center shadow-md"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Skill
              </button>
            )}
          </div>
          
          <div className="space-y-4">
          {formData.technicalSkills.map((skill, index) => (
            <div key={index} className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <div className="flex items-center space-x-4">
              <input
                type="text"
                placeholder="Skill name"
                value={skill.skill}
                onChange={(e) => handleArrayInputChange('technicalSkills', index, 'skill', e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors text-sm"
              />
              <div className="flex items-center space-x-2 w-28">
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={skill.percentage}
                  onChange={(e) => handleArrayInputChange('technicalSkills', index, 'percentage', parseInt(e.target.value))}
                  className="flex-1 accent-yellow-500"
                />
                <span className="text-xs font-medium w-8 text-gray-600">{skill.percentage}%</span>
              </div>
              {formData.technicalSkills.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeArrayItem('technicalSkills', index)}
                  className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-lg transition-colors text-xs font-medium"
                >
                  Delete
                </button>
              )}
              </div>
            </div>
          ))}
          </div>
        </section>

        {/* Soft Skills */}
        <section className="border-b border-gray-200 pb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Heart className="w-6 h-6 text-yellow-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Soft Skills</h2>
            </div>
            {formData.softSkills.length < 3 && (
              <button
                type="button"
                onClick={() => addArrayItem('softSkills', { skill: '', percentage: 50 })}
                className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center shadow-md"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Skill
              </button>
            )}
          </div>
          
          <div className="space-y-4">
          {formData.softSkills.map((skill, index) => (
            <div key={index} className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <div className="flex items-center space-x-4">
              <input
                type="text"
                placeholder="Skill name"
                value={skill.skill}
                onChange={(e) => handleArrayInputChange('softSkills', index, 'skill', e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors text-sm"
              />
              <div className="flex items-center space-x-2 w-28">
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={skill.percentage}
                  onChange={(e) => handleArrayInputChange('softSkills', index, 'percentage', parseInt(e.target.value))}
                  className="flex-1 accent-yellow-500"
                />
                <span className="text-xs font-medium w-8 text-gray-600">{skill.percentage}%</span>
              </div>
              {formData.softSkills.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeArrayItem('softSkills', index)}
                  className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-lg transition-colors text-xs font-medium"
                >
                  Delete
                </button>
              )}
              </div>
            </div>
          ))}
          </div>
        </section>

        {/* Certifications */}
        <section className="border-b border-gray-200 pb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Award className="w-6 h-6 text-yellow-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Certifications</h2>
            </div>
            {formData.certifications.length < 4 && (
              <button
                type="button"
                onClick={() => addArrayItem('certifications', '')}
                className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center shadow-md"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Certification
              </button>
            )}
          </div>
          
          {formData.certifications.map((cert, index) => (
            <div key={index} className="flex items-center space-x-4 mb-4 bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <input
                type="text"
                placeholder="Certification name"
                value={cert}
                onChange={(e) => handleSimpleArrayChange('certifications', index, e.target.value)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
              />
              {formData.certifications.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeArrayItem('certifications', index)}
                  className="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg transition-colors text-sm font-medium"
                >
                  Delete
                </button>
              )}
            </div>
          ))}
        </section>

        {/* Achievements */}
        <section className="border-b border-gray-200 pb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Star className="w-6 h-6 text-yellow-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Achievements</h2>
            </div>
            {formData.achievements.length < 5 && (
              <button
                type="button"
                onClick={() => addArrayItem('achievements', '')}
                className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center shadow-md"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Achievement
              </button>
            )}
          </div>
          
          {formData.achievements.map((achievement, index) => (
            <div key={index} className="flex items-center space-x-4 mb-4 bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <input
                type="text"
                placeholder="Achievement description"
                value={achievement}
                onChange={(e) => handleSimpleArrayChange('achievements', index, e.target.value)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
              />
              {formData.achievements.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeArrayItem('achievements', index)}
                  className="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg transition-colors text-sm font-medium"
                >
                  Delete
                </button>
              )}
            </div>
          ))}
        </section>

        {/* Extracurricular Activities */}
        <section className="border-b border-gray-200 pb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Calendar className="w-6 h-6 text-yellow-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Extracurricular Activities</h2>
            </div>
            {formData.extracurricularActivities.length < 5 && (
              <button
                type="button"
                onClick={() => addArrayItem('extracurricularActivities', { title: '', date: '', details: '' })}
                className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center shadow-md"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Activity
              </button>
            )}
          </div>
          
          {formData.extracurricularActivities.map((activity, index) => (
            <div key={index} className="bg-yellow-50 p-6 rounded-lg mb-4 border border-yellow-200">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Activity {index + 1}</h3>
                {formData.extracurricularActivities.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeArrayItem('extracurricularActivities', index)}
                    className="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg transition-colors text-sm font-medium"
                  >
                    Delete
                  </button>
                )}
              </div>
              
              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <input
                  type="text"
                  placeholder="Activity title"
                  value={activity.title}
                  onChange={(e) => handleArrayInputChange('extracurricularActivities', index, 'title', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                />
                <input
                  type="text"
                  placeholder="Date"
                  value={activity.date}
                  onChange={(e) => handleArrayInputChange('extracurricularActivities', index, 'date', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                />
              </div>
              
              <textarea
                placeholder="Activity details..."
                value={activity.details}
                onChange={(e) => handleArrayInputChange('extracurricularActivities', index, 'details', e.target.value)}
                rows={2}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
              />
            </div>
          ))}
        </section>

        {/* Reference */}
        <section className="border-b border-gray-200 pb-8">
          <div className="flex items-center mb-6">
            <Users className="w-6 h-6 text-yellow-600 mr-3" />
            <h2 className="text-2xl font-semibold text-gray-900">Reference (Optional)</h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <input
              type="text"
              placeholder="Reference Name"
              value={formData.reference.name}
              onChange={(e) => handleNestedInputChange('reference', 'name', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
            />
            <input
              type="text"
              placeholder="Position"
              value={formData.reference.position}
              onChange={(e) => handleNestedInputChange('reference', 'position', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
            />
            <input
              type="text"
              placeholder="Company"
              value={formData.reference.company}
              onChange={(e) => handleNestedInputChange('reference', 'company', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
            />
            <input
              type="text"
              placeholder="Contact Information"
              value={formData.reference.contact}
              onChange={(e) => handleNestedInputChange('reference', 'contact', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
            />
          </div>
        </section>

        {/* Submit Button */}
        <div className="text-center pt-6">
          <button
            type="submit"
            disabled={isSubmitting}
            className="bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-600 hover:to-amber-600 disabled:from-gray-400 disabled:to-gray-500 text-white font-semibold px-8 py-3 rounded-lg transition-all duration-200 flex items-center mx-auto transform hover:scale-105 disabled:transform-none disabled:cursor-not-allowed shadow-lg"
          >
            {isSubmitting ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-3"></div>
                Submitting...
              </>
            ) : (
              <>
                <Send className="w-5 h-5 mr-3" />
                Submit Resume
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ResumeForm;